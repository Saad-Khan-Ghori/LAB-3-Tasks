#include<stdio.h>
int main(){
	int length, width, area;
	printf("Enter length of the rectangle:\n");
	scanf("%d",&length);
	printf("Enter width of the rectangle: \n");
	scanf("%d",&width);
	area = length *width;
	printf("Area of the triangle is %d",area);
	
	
}
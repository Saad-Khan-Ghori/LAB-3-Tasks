#include<stdio.h>
int main(){
	int testinteger = 45;
	printf("Number is %d",testinteger);
}